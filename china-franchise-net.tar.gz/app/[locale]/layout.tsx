import Link from 'next/link';
import { notFound } from 'next/navigation';
import type { Locale } from '@/lib/i18n';
import { translations, locales } from '@/lib/i18n';
import LocaleClientLayout from '@/components/front/LocaleClientLayout';

interface Props {
  children: React.ReactNode;
  params: { locale: string };
}

export default function LocaleLayout({ children, params }: Props) {
  const locale = params.locale as Locale;
  if (!locales.includes(locale)) {
    notFound();
  }

  return (
    <LocaleClientLayout locale={locale}>
      {children}
    </LocaleClientLayout>
  );
}
