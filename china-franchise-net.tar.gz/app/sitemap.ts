import { MetadataRoute } from 'next';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = process.env.SITE_URL || 'https://www.cnfranchise.com';

  // 获取所有已发布的品牌
  const brands = await prisma.brand.findMany({
    where: { status: 'published' },
    select: { slug: true, updatedAt: true },
  });

  // 固定页面
  const staticPages: MetadataRoute.Sitemap = [
    { url: baseUrl, lastModified: new Date(), changeFrequency: 'daily', priority: 1.0 },
    { url: `${baseUrl}/search`, lastModified: new Date(), changeFrequency: 'daily', priority: 0.9 },
  ];

  // 分类页面
  const categories = ['chayin', 'kafei', 'xiaochi', 'tianpin', 'tangshui', 'canyin'];
  const categoryPages: MetadataRoute.Sitemap = categories.map(slug => ({
    url: `${baseUrl}/category/${slug}`,
    lastModified: new Date(),
    changeFrequency: 'weekly' as const,
    priority: 0.8,
  }));

  // 品牌详情页
  const brandPages: MetadataRoute.Sitemap = brands.map(brand => ({
    url: `${baseUrl}/brand/${brand.slug}`,
    lastModified: brand.updatedAt || new Date(),
    changeFrequency: 'monthly' as const,
    priority: 0.7,
  }));

  return [...staticPages, ...categoryPages, ...brandPages];
}
